import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  Modal,
  Image,
  ImageBackground,
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const menuItems = [
  { id: 1, name: 'Margherita Pizza', price: 450, img: 'https://images.pexels.com/photos/1166120/pexels-photo-1166120.jpeg', category: 'Pizza' },
  { id: 2, name: 'Chicken Tikka Pizza', price: 550, img: 'https://images.pexels.com/photos/825661/pexels-photo-825661.jpeg', category: 'Pizza' },
  { id: 3, name: 'Pepperoni Feast', price: 650, img: 'https://images.pexels.com/photos/4109078/pexels-photo-4109078.jpeg', category: 'Pizza' },
  { id: 4, name: 'Veggie Supreme', price: 500, img: 'https://images.pexels.com/photos/1583884/pexels-photo-1583884.jpeg', category: 'Pizza' },
  { id: 5, name: 'Cheeseburger Deluxe', price: 350, img: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg', category: 'Burger' },
  { id: 6, name: 'Zinger Burger', price: 380, img: 'https://images.pexels.com/photos/1600711/pexels-photo-1600711.jpeg', category: 'Burger' },
  { id: 7, name: 'Grilled Chicken Sandwich', price: 480, img: 'https://images.pexels.com/photos/1603901/pexels-photo-1603901.jpeg', category: 'Sandwich' },
  { id: 8, name: 'Club Sandwich & Fries', price: 420, img: 'https://images.pexels.com/photos/1600727/pexels-photo-1600727.jpeg', category: 'Sandwich' },
  { id: 9, name: 'French Fries', price: 200, img: 'https://images.pexels.com/photos/1583884/pexels-photo-1583884.jpeg', category: 'Sides' },
  { id: 10, name: 'Masala Fries', price: 230, img: 'https://images.pexels.com/photos/115740/pexels-photo-115740.jpeg', category: 'Sides' },
  { id: 11, name: 'Nuggets (6pcs)', price: 300, img: 'https://images.pexels.com/photos/6061611/pexels-photo-6061611.jpeg', category: 'Sides' },
  { id: 12, name: 'Garlic Bread (4pcs)', price: 180, img: 'https://images.pexels.com/photos/1209029/pexels-photo-1209029.jpeg', category: 'Sides' },
  { id: 13, name: 'Alfredo Pasta', price: 590, img: 'https://images.pexels.com/photos/1437267/pexels-photo-1437267.jpeg', category: 'Pasta' },
  { id: 14, name: 'Mac n Cheese', price: 450, img: 'https://images.pexels.com/photos/5410414/pexels-photo-5410414.jpeg', category: 'Pasta' },
  { id: 15, name: 'Grilled Platter', price: 1200, img: 'https://images.pexels.com/photos/2641886/pexels-photo-2641886.jpeg', category: 'Platters' },
  { id: 16, name: 'Iced Latte', price: 250, img: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg', category: 'Drinks' },
  { id: 17, name: 'Cold Drink (Regular)', price: 120, img: 'https://images.pexels.com/photos/1233319/pexels-photo-1233319.jpeg', category: 'Drinks' },
  { id: 18, name: 'Fresh Lime', price: 150, img: 'https://images.pexels.com/photos/414630/pexels-photo-414630.jpeg', category: 'Drinks' },
  { id: 19, name: 'Chocolate Lava Cake', price: 350, img: 'https://images.pexels.com/photos/1126359/pexels-photo-1126359.jpeg', category: 'Dessert' },
  { id: 20, name: 'Ice Cream Scoop', price: 150, img: 'https://images.pexels.com/photos/1352245/pexels-photo-1352245.jpeg', category: 'Dessert' },
  { id: 21, name: 'Solo Deal (1 Burger + Drink)', price: 450, img: 'https://images.pexels.com/photos/2271107/pexels-photo-2271107.jpeg', category: 'Deals' },
  { id: 22, name: 'Buddy Pack (2 Pizza + Drink)', price: 999, img: 'https://images.pexels.com/photos/367915/pexels-photo-367915.jpeg', category: 'Deals' },
];

export default function App() {
  return (
    <SafeAreaProvider>
      <AppNavigator />
    </SafeAreaProvider>
  );
}

function AppNavigator() {
  const [currentScreen, setCurrentScreen] = useState('login');
  const [user, setUser] = useState(null);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [cartItems, setCartItems] = useState([]);
  const [orderHistory, setOrderHistory] = useState([]); // <--- NEW: Store past orders
  const [isScanning, setIsScanning] = useState(false);
  const [showTableInfo, setShowTableInfo] = useState(false);
  const [lastReservedTable, setLastReservedTable] = useState(null);

  const [paymentMethod, setPaymentMethod] = useState('');
  const [paymentNumber, setPaymentNumber] = useState('');

  const [tables, setTables] = useState([
    { id: 1, status: 'available', freeAt: null },
    { id: 2, status: 'available', freeAt: null },
    { id: 3, status: 'reserved', freeAt: Date.now() + 600000 },
    { id: 4, status: 'available', freeAt: null },
    { id: 5, status: 'reserved', freeAt: Date.now() + 1200000 },
    { id: 6, status: 'available', freeAt: null },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTables((currentTables) =>
        currentTables.map((table) => {
          if (table.status === 'reserved' && table.freeAt && Date.now() > table.freeAt) {
            return { ...table, status: 'available', freeAt: null };
          }
          return table;
        })
      );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleStartScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setShowTableInfo(true);
    }, 2000);
  };

  const handleReserveTable = (tableId) => {
    setTables((prev) =>
      prev.map((t) =>
        t.id === tableId ? { ...t, status: 'reserved', freeAt: Date.now() + 1800000 } : t
      )
    );
    setLastReservedTable(tableId);
    setShowTableInfo(false);
    setCurrentScreen('reservationSuccess');
  };

  const getRemainingTime = (freeAt) => {
    if (!freeAt) return 'READY';
    const diff = Math.max(0, freeAt - Date.now());
    const mins = Math.floor(diff / 60000);
    const secs = Math.floor((diff % 60000) / 1000);
    return `${mins}m ${secs}s`;
  };

  const totalPrice = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const availableTablesCount = tables.filter((t) => t.status === 'available').length;

  const addItemToCart = (item) => {
    setCartItems((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const Header = ({ title, onBack, cartCount, showProfile = true }) => (
    <View style={styles.header}>
      <TouchableOpacity onPress={onBack} style={styles.backBtn}>
        <MaterialCommunityIcons name="chevron-left" size={28} color="#FFF" />
      </TouchableOpacity>
      <View style={styles.headerTitleContainer}>
        <Text style={styles.headerTitleMain}>CHEEZIOUS</Text>
        <Text style={styles.headerTitleSub}>AUTHENTIC FLAVORS</Text>
      </View>
      <View style={styles.headerRightActions}>
        {showProfile && (
          <TouchableOpacity onPress={() => setCurrentScreen('profile')} style={styles.profileIconBtn}>
            <MaterialCommunityIcons name="account-circle-outline" size={24} color="#FFF" />
          </TouchableOpacity>
        )}
        <View style={styles.cartCountBadge}>
          <Text style={styles.cartCountText}>{cartCount}</Text>
        </View>
      </View>
    </View>
  );

  // --- SCREEN RENDERING ---

  if (currentScreen === 'login') {
    return (
      <ImageBackground
        source={{ uri: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg' }}
        style={styles.loginBackground}
        blurRadius={2}>
        <View style={styles.darkOverlay}>
          <View style={styles.loginCard}>
            <View style={styles.logoCircleLarge}>
              <Image source={{ uri: 'https://images.pexels.com/photos/1166120/pexels-photo-1166120.jpeg' }} style={styles.logoImg} />
            </View>
            <Text style={styles.professionalTitle}>CHEEZIOUS</Text>
            <Text style={styles.tagline}>The Best Pizza in Town</Text>
            <View style={styles.inputContainer}>
              <TextInput style={styles.modernInput} placeholder="Email Address" placeholderTextColor="#999" value={loginEmail} onChangeText={setLoginEmail} />
              <TextInput style={styles.modernInput} placeholder="Password" placeholderTextColor="#999" secureTextEntry value={loginPass} onChangeText={setLoginPass} />
            </View>
            <TouchableOpacity
              style={styles.premiumBtn}
              onPress={() => {
                if (loginEmail.length > 2 && loginPass.length > 2) {
                  setUser({ name: loginEmail.split('@')[0], email: loginEmail });
                  setCurrentScreen('menu');
                } else {
                  Alert.alert('Error', 'Please enter valid credentials');
                }
              }}>
              <Text style={styles.premiumBtnText}>SIGN IN</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ImageBackground>
    );
  }

  if (currentScreen === 'menu') {
    return (
      <SafeAreaView style={styles.appContainer}>
        <Header title="Menu" onBack={() => setCurrentScreen('login')} cartCount={cartItems.length} />
        <ScrollView>
          <View style={styles.gridWrapper}>
            {menuItems.map((item) => (
              <View key={item.id} style={styles.gridItem}>
                <Image source={{ uri: item.img }} style={styles.itemImage} />
                <Text style={styles.gridItemName}>{item.name}</Text>
                <Text style={styles.gridItemPrice}>Rs. {item.price}</Text>
                <TouchableOpacity style={styles.addSmallBtn} onPress={() => addItemToCart(item)}>
                  <Text style={styles.addBtnText}>ADD +</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
          <View style={styles.bottomSection}>
            <TouchableOpacity style={styles.scanButtonAction} onPress={handleStartScan}>
              <View style={styles.scanIconContainer}>
                <MaterialCommunityIcons name="table-chair" size={32} color="#FF6B00" />
              </View>
              <View style={styles.scanTextContainer}>
                <Text style={styles.scanButtonText}>BOOK A TABLE</Text>
                <Text style={styles.scanButtonSubText}>{availableTablesCount} Tables Available Now</Text>
              </View>
              <MaterialCommunityIcons name="chevron-right" size={24} color="#FF6B00" />
            </TouchableOpacity>
          </View>
        </ScrollView>
        {cartItems.length > 0 && (
          <TouchableOpacity style={styles.cartBtn} onPress={() => setCurrentScreen('cart')}>
            <Text style={styles.cartBtnText}>VIEW CART - Rs. {totalPrice}</Text>
          </TouchableOpacity>
        )}
        <Modal visible={isScanning} transparent={true} animationType="fade">
          <View style={styles.fullOverlay}>
            <View style={styles.scanningBox}>
              <ActivityIndicator size="large" color="#FF6B00" />
              <Text style={styles.scanningText}>SCANNING QR...</Text>
            </View>
          </View>
        </Modal>
        <Modal visible={showTableInfo} transparent={true} animationType="slide">
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>SELECT A TABLE</Text>
              <ScrollView style={styles.tableList}>
                {tables.map((t) => (
                  <View key={t.id} style={styles.tableRow}>
                    <View>
                      <Text style={styles.tableLabel}>Table #{t.id}</Text>
                      <Text style={{ fontSize: 10, color: '#888' }}>
                        {t.status === 'reserved' ? `Free in: ${getRemainingTime(t.freeAt)}` : 'Ready to Sit'}
                      </Text>
                    </View>
                    {t.status === 'available' ? (
                      <TouchableOpacity style={styles.reserveNowBtn} onPress={() => handleReserveTable(t.id)}>
                        <Text style={styles.reserveNowText}>RESERVE</Text>
                      </TouchableOpacity>
                    ) : (
                      <View style={[styles.statusBadge, styles.statusRed]}>
                        <Text style={styles.badgeText}>BUSY</Text>
                      </View>
                    )}
                  </View>
                ))}
              </ScrollView>
              <TouchableOpacity style={styles.closeBtn} onPress={() => setShowTableInfo(false)}>
                <Text style={styles.closeBtnText}>CLOSE</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </SafeAreaView>
    );
  }

  if (currentScreen === 'reservationSuccess') {
    return (
      <SafeAreaView style={[styles.appContainer, { backgroundColor: '#FFF' }]}>
        <View style={styles.successContainer}>
          <View style={styles.checkCircle}>
            <MaterialCommunityIcons name="check-decagram" size={60} color="#4CAF50" />
          </View>
          <Text style={styles.successTitle}>RESERVED!</Text>
          <Text style={styles.successSub}>Table #{lastReservedTable} is now yours.</Text>
          <TouchableOpacity style={styles.mainBtn} onPress={() => setCurrentScreen('menu')}>
            <Text style={styles.mainBtnText}>BACK TO MENU</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (currentScreen === 'cart') {
    return (
      <SafeAreaView style={styles.appContainer}>
        <Header title="Cart" onBack={() => setCurrentScreen('menu')} cartCount={cartItems.length} />
        <ScrollView style={styles.contentPadding}>
          {cartItems.map((i) => (
            <View style={styles.cartItemRow} key={i.id}>
              <Text style={styles.cartItemText}>{i.name} x{i.quantity}</Text>
              <Text style={styles.cartItemPrice}>Rs. {i.price * i.quantity}</Text>
            </View>
          ))}
          <View style={styles.divider} />
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Subtotal</Text>
            <Text style={styles.totalAmount}>Rs. {totalPrice}</Text>
          </View>
          <TouchableOpacity style={styles.mainBtn} onPress={() => setCurrentScreen('checkout')}>
            <Text style={styles.mainBtnText}>PROCEED TO CHECKOUT</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (currentScreen === 'checkout') {
    return (
      <SafeAreaView style={styles.appContainer}>
        <Header title="Checkout" onBack={() => setCurrentScreen('cart')} cartCount={cartItems.length} />
        <ScrollView style={styles.contentPadding}>
          <View style={styles.summaryCard}>
            <Text style={styles.summaryTitle}>ORDER SUMMARY</Text>
            {cartItems.map((item) => (
              <View key={item.id} style={styles.summaryRow}>
                <Text style={styles.summaryText}>{item.quantity}x {item.name}</Text>
                <Text style={styles.summaryPrice}>Rs. {item.price * item.quantity}</Text>
              </View>
            ))}
            <View style={styles.divider} />
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Grand Total</Text>
              <Text style={styles.totalAmount}>Rs. {totalPrice}</Text>
            </View>
          </View>

          <Text style={styles.sectionHeading}>SELECT PAYMENT METHOD</Text>
          <View style={styles.paymentGrid}>
            {[
              { id: '💳EasyPaisa', label: 'EasyPaisa', icon: 'wallet' },
              { id: '💳JazzCash', label: 'JazzCash', icon: 'cellphone-check' },
              { id: '💳Bank Transfer', label: 'Bank', icon: 'bank' },
              { id: '🚲COD', label: 'Cash on Delivery', icon: 'bike' },
            ].map((method) => (
              <TouchableOpacity
                key={method.id}
                style={[styles.modernPaymentBtn, paymentMethod === method.id && styles.selectedPaymentModern]}
                onPress={() => setPaymentMethod(method.id)}>
                <MaterialCommunityIcons name={method.icon} size={24} color={paymentMethod === method.id ? '#FF6B00' : '#666'} />
                <Text style={[styles.paymentBtnText, paymentMethod === method.id && styles.selectedPaymentText]}>{method.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {paymentMethod !== '' && (
            <View style={styles.inputSlideIn}>
              {paymentMethod !== '🚲COD' && (
                <View>
                  <Text style={styles.inputLabel}>Account Number</Text>
                  <TextInput style={styles.modernInput} keyboardType="numeric" placeholder="03xx xxxxxxx" value={paymentNumber} onChangeText={setPaymentNumber} />
                </View>
              )}
              <TouchableOpacity
                style={styles.confirmOrderBtn}
                onPress={() => {
                  if (paymentMethod !== '🚲COD' && paymentNumber.length < 10) {
                    Alert.alert("Invalid Number", "Please enter a valid account number");
                    return;
                  }
                  
                  // SAVE ORDER TO HISTORY BEFORE CLEARING
                  const newOrder = {
                    id: Math.floor(Math.random() * 10000),
                    items: [...cartItems],
                    total: totalPrice,
                    date: new Date().toLocaleDateString(),
                  };
                  setOrderHistory([newOrder, ...orderHistory]);

                  setCartItems([]);
                  setPaymentMethod('');
                  setPaymentNumber('');
                  setCurrentScreen('orderSuccess');
                }}>
                <Text style={styles.confirmOrderText}>{paymentMethod === '🚲COD' ? 'PLACE ORDER' : 'PAY & CONFIRM'}</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (currentScreen === 'orderSuccess') {
    return (
      <SafeAreaView style={styles.appContainer}>
        <View style={styles.successContainer}>
            <View style={styles.checkCircle}>
                <MaterialCommunityIcons name="silverware-clean" size={60} color="#FF6B00" />
            </View>
            <Text style={styles.successTitle}>THANK YOU!</Text>
            <Text style={styles.successSub}>Your order has been placed successfully.</Text>
            <TouchableOpacity style={styles.mainBtn} onPress={() => setCurrentScreen('menu')}>
                <Text style={styles.mainBtnText}>BACK TO HOME</Text>
            </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (currentScreen === 'profile') {
    return (
      <SafeAreaView style={styles.appContainer}>
        <Header 
          title="My Profile" 
          onBack={() => setCurrentScreen('menu')} 
          cartCount={cartItems.length} 
          showProfile={false} 
        />
        
        <ScrollView contentContainerStyle={styles.contentPadding}>
          {/* User Profile Card */}
          <View style={styles.summaryCard}>
            <View style={styles.profileHeaderRow}>
              <View style={styles.avatarCircle}>
                <Text style={styles.avatarText}>
                  {user?.name?.charAt(0).toUpperCase() || 'U'}
                </Text>
              </View>
              <View style={styles.userInfoText}>
                <Text style={styles.sectionHeading}>USER DETAILS</Text>
                <Text style={styles.profileNameText}>{user?.name || 'Guest User'}</Text>
                <Text style={styles.summaryText}>{user?.email}</Text>
              </View>
            </View>
          </View>

          {/* Track Active Order - Only shows if there's a recent order */}
          {orderHistory.length > 0 && (
            <>
            <Text style={styles.sectionHeading}>TRACK ACTIVE ORDER</Text>
            <View style={styles.summaryCard}>
              <View style={styles.trackRow}>
                <MaterialCommunityIcons name="moped" size={24} color="#FF6B00" />
                <Text style={styles.trackStatusText}>Order #{orderHistory[0].id} is on the way!</Text>
              </View>
              
              <View style={styles.progressBarBg}>
                <View style={[styles.progressBarFill, { width: '65%' }]} />
              </View>
              
              <View style={styles.trackStepLabels}>
                <Text style={styles.stepTextActive}>Prep</Text>
                <Text style={styles.stepTextActive}>Baking</Text>
                <Text style={styles.stepText}>Delivery</Text>
              </View>
              <TouchableOpacity 
                style={styles.trackDetailsBtn}
                onPress={() => Alert.alert("Order Tracking", "Your rider is nearby!")}>
                <Text style={styles.trackDetailsBtnText}>VIEW MAP</Text>
              </TouchableOpacity>
            </View>
            </>
          )}

          {/* REAL ORDER HISTORY */}
          <Text style={styles.sectionHeading}>ORDER HISTORY</Text>
          {orderHistory.length === 0 ? (
             <View style={styles.summaryCard}>
                <Text style={{textAlign: 'center', color: '#999'}}>No past orders found.</Text>
             </View>
          ) : (
            orderHistory.map((order) => (
              <View key={order.id} style={styles.summaryCard}>
                <View style={styles.menuItemRow}>
                  <View>
                    <Text style={{fontWeight: 'bold'}}>Order #{order.id}</Text>
                    <Text style={{fontSize: 12, color: '#666'}}>{order.date}</Text>
                    <Text style={{fontSize: 12, color: '#444', marginTop: 5}}>
                      {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                    </Text>
                  </View>
                  <Text style={{fontWeight: '900', color: '#FF6B00'}}>Rs. {order.total}</Text>
                </View>
              </View>
            ))
          )}

          <TouchableOpacity 
            style={[styles.mainBtn, { backgroundColor: '#333', marginTop: 10 }]} 
            onPress={() => {
              setCartItems([]);
              setOrderHistory([]);
              setCurrentScreen('login');
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <MaterialCommunityIcons name="logout" size={20} color="#FFF" style={{ marginRight: 10 }} />
              <Text style={styles.mainBtnText}>LOGOUT</Text>
            </View>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    paddingHorizontal: 15,
    paddingBottom: 15,
    backgroundColor: '#FF6B00',
    alignItems: 'center',
    paddingTop: 50,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  headerTitleContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  headerTitleMain: { color: '#FFF', fontSize: 20, fontWeight: '900', letterSpacing: 3 },
  headerTitleSub: { color: 'rgba(255,255,255,0.8)', fontSize: 8, fontWeight: 'bold', letterSpacing: 2, marginTop: -2 },
  headerRightActions: { flexDirection: 'row', alignItems: 'center' },
  cartCountBadge: { backgroundColor: '#FFF', width: 22, height: 22, borderRadius: 11, justifyContent: 'center', alignItems: 'center', marginLeft: 8 },
  cartCountText: { color: '#FF6B00', fontWeight: 'bold', fontSize: 11 },
  profileIconBtn: { padding: 2 },
  backBtn: { width: 40 },
  loginBackground: { flex: 1, width: '100%', height: '100%' },
  darkOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', alignItems: 'center' },
  loginCard: { width: '85%', backgroundColor: 'rgba(255,255,255,0.92)', borderRadius: 30, padding: 25, alignItems: 'center' },
  logoCircleLarge: { width: 90, height: 90, borderRadius: 45, overflow: 'hidden', borderWidth: 3, borderColor: '#FF6B00', marginBottom: 15 },
  logoImg: { width: '100%', height: '100%' },
  professionalTitle: { fontSize: 28, fontWeight: '900', color: '#1A1A1A' },
  tagline: { fontSize: 13, color: '#666', marginBottom: 25 },
  inputContainer: { width: '100%', marginBottom: 20 },
  modernInput: { width: '100%', height: 50, backgroundColor: '#F0F0F0', borderRadius: 12, paddingHorizontal: 15, marginBottom: 15 },
  premiumBtn: { width: '100%', height: 55, backgroundColor: '#FF6B00', borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  premiumBtnText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  appContainer: { flex: 1, backgroundColor: '#F9F9F9' },
  gridWrapper: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around', padding: 10 },
  gridItem: { width: '45%', backgroundColor: '#FFF', borderRadius: 10, padding: 10, marginBottom: 15, alignItems: 'center', elevation: 2 },
  itemImage: { width: '100%', height: 80, borderRadius: 8 },
  gridItemName: { fontWeight: 'bold', fontSize: 10, marginTop: 5 },
  gridItemPrice: { color: '#FF6B00', fontWeight: 'bold', fontSize: 12 },
  addSmallBtn: { backgroundColor: '#FF6B00', padding: 6, borderRadius: 5, marginTop: 5, width: '100%', alignItems: 'center' },
  addBtnText: { color: 'white', fontSize: 10, fontWeight: 'bold' },
  bottomSection: { borderTopWidth: 1, borderColor: '#EEE', marginTop: 10, backgroundColor: '#FFF' },
  scanButtonAction: { margin: 15, padding: 15, backgroundColor: '#FFF', borderRadius: 15, flexDirection: 'row', alignItems: 'center', elevation: 3 },
  scanIconContainer: { width: 50, height: 50, borderRadius: 12, backgroundColor: '#FFF3E0', justifyContent: 'center', alignItems: 'center' },
  scanTextContainer: { flex: 1, marginLeft: 15 },
  scanButtonText: { fontSize: 16, fontWeight: 'bold', color: '#1A1A1A' },
  scanButtonSubText: { fontSize: 12, color: '#FF6B00', marginTop: 2 },
  cartBtn: { backgroundColor: '#1A1A1A', padding: 18, margin: 15, borderRadius: 12, alignItems: 'center', position: 'absolute', bottom: 0, left: 0, right: 0 },
  cartBtnText: { color: '#FFF', fontWeight: 'bold' },
  cartItemRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15, backgroundColor: '#FFF', padding: 15, borderRadius: 10 },
  cartItemText: { fontWeight: '600' },
  cartItemPrice: { color: '#FF6B00', fontWeight: 'bold' },
  successContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  checkCircle: { width: 120, height: 120, borderRadius: 60, backgroundColor: '#FFF3E0', justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  successTitle: { fontSize: 32, fontWeight: '900', color: '#FF6B00' },
  successSub: { fontSize: 16, color: '#666', marginBottom: 30, textAlign: 'center' },
  mainBtn: { backgroundColor: '#FF6B00', padding: 18, borderRadius: 12, width: '100%', alignItems: 'center', marginTop: 10 },
  mainBtnText: { color: '#FFF', fontWeight: 'bold' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: 'white', padding: 20, borderRadius: 20, width: '85%', maxHeight: '70%' },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15, textAlign: 'center' },
  tableRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderColor: '#EEE' },
  tableLabel: { fontWeight: 'bold', fontSize: 14 },
  reserveNowBtn: { backgroundColor: '#FF6B00', paddingHorizontal: 15, paddingVertical: 8, borderRadius: 8 },
  reserveNowText: { color: 'white', fontSize: 12, fontWeight: 'bold' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 5 },
  statusRed: { backgroundColor: '#FFEBEE' },
  badgeText: { color: '#F44336', fontSize: 10, fontWeight: 'bold' },
  closeBtn: { marginTop: 15, padding: 15, alignItems: 'center' },
  closeBtnText: { color: '#666', fontWeight: 'bold' },
  summaryCard: { backgroundColor: '#FFF', borderRadius: 15, padding: 20, marginBottom: 10, elevation: 4 },
  summaryTitle: { fontSize: 12, fontWeight: 'bold', color: '#999', marginBottom: 15, letterSpacing: 1 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  summaryText: { color: '#444', fontSize: 14 },
  summaryPrice: { fontWeight: '600', color: '#1A1A1A' },
  divider: { height: 1, backgroundColor: '#EEE', marginVertical: 15 },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: 16, fontWeight: 'bold', color: '#1A1A1A' },
  totalAmount: { fontSize: 20, fontWeight: '900', color: '#FF6B00' },
  sectionHeading: { fontSize: 14, fontWeight: 'bold', color: '#333', marginBottom: 10, marginTop: 15, marginLeft: 5 },
  paymentGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  modernPaymentBtn: { width: '48%', backgroundColor: '#FFF', padding: 15, borderRadius: 12, alignItems: 'center', marginBottom: 15, borderWidth: 1.5, borderColor: '#EEE' },
  selectedPaymentModern: { borderColor: '#FF6B00', backgroundColor: '#FFF9F5' },
  paymentBtnText: { marginTop: 8, fontSize: 12, fontWeight: '600', color: '#666' },
  selectedPaymentText: { color: '#FF6B00' },
  inputSlideIn: { marginTop: 10 },
  inputLabel: { fontSize: 12, fontWeight: 'bold', color: '#666', marginBottom: 8, marginLeft: 5 },
  confirmOrderBtn: { backgroundColor: '#1A1A1A', padding: 20, borderRadius: 15, alignItems: 'center', marginTop: 10, marginBottom: 30 },
  confirmOrderText: { color: '#FFF', fontWeight: '900', fontSize: 16, letterSpacing: 1 },
  contentPadding: { padding: 20 },
  fullOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', alignItems: 'center' },
  scanningBox: { backgroundColor: '#FFF', padding: 30, borderRadius: 20, alignItems: 'center' },
  scanningText: { marginTop: 15, fontWeight: 'bold' },
  profileHeaderRow: { flexDirection: 'row', alignItems: 'center' },
  avatarCircle: { width: 60, height: 60, borderRadius: 30, backgroundColor: '#FF6B00', justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  avatarText: { color: '#FFF', fontSize: 24, fontWeight: 'bold' },
  profileNameText: { fontSize: 18, fontWeight: 'bold', color: '#1A1A1A' },
  userInfoText: { flex: 1 },
  trackRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  trackStatusText: { marginLeft: 10, fontWeight: 'bold', color: '#1A1A1A' },
  progressBarBg: { height: 8, backgroundColor: '#EEE', borderRadius: 4, overflow: 'hidden', marginBottom: 8 },
  progressBarFill: { height: '100%', backgroundColor: '#FF6B00' },
  trackStepLabels: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15 },
  stepText: { fontSize: 10, color: '#BBB' },
  stepTextActive: { fontSize: 10, color: '#FF6B00', fontWeight: 'bold' },
  trackDetailsBtn: { borderWidth: 1, borderColor: '#FF6B00', padding: 10, borderRadius: 8, alignItems: 'center' },
  trackDetailsBtnText: { color: '#FF6B00', fontWeight: 'bold', fontSize: 12 },
  menuItemRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
});